﻿/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.editorConfig = function( config )
{
	 config.language = 'zh-cn';
	 config.resize_enabled = false;
	 config.removePlugins="save,print"
	 config.font_names='宋体;楷体;黑体';
	 config.fontSize_sizes='14;18;20'
	 config.extraPlugins="doubleToSingle,pagebreak_withTitle"
};
