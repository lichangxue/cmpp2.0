// controlsUI_cfg.js 引用该变量值
var Designer_controls_formTemplate = [
	['template_1', '标准视图', '标准视图是CMPP的默认视图,能实现表单的保存预览等所有完整功能。'], 
	['template_for_idxEditor', '碎片编辑视图', '页面可视化编辑时点击浮层弹出的编辑视图。'],
	['template_for_templateDesign', '碎片设计视图', '模板可视化编辑过程中切碎片弹出的碎片配置视图即为碎片设计视图。'],
	['template_for_tuijianwei', '推荐位数据项编辑视图', '推荐位控件有个编辑按钮，点击按钮弹出的编辑视图即为推荐位数据项编辑视图，该视图可实现推荐位数据项的数据编辑。']
];