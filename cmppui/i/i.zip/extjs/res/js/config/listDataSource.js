//新建列表视图引用变量
var Designer_controls_listDataSource = [
    ['default','默认数据源'],
    ['sql','自定义SQL数据源'],
    ['url','自定义URL数据源']
];